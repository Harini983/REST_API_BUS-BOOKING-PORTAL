# d68339e8-5f11-49f1-b41a-db124fbe69fa-f0eff0f5-c5f5-4228-b9ea-731aaaf1df51
Repository for Teams Project code and project management
